﻿<Serializable()>
Public Class HighScore

    Public HighScore As Integer

End Class
