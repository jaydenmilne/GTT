﻿Public Module EntityTypes

    Public Enum Entities
        Ship
        NonCollisionableObject
        Laser
        Projectile
        FILE_NOT_FOUND
    End Enum

    Public Enum MyFavoriteColor
        Red
        Blue
        Yellow
        Turquoise
        YOUR_MOM
    End Enum

End Module
