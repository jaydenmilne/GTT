﻿Public Class Diagnostics

    Public Shared UpdateTime As Double
    Public Shared RenderTime As Double
    Public Shared BufferRender As Double
    Public Shared CollisionTime As Double
    Public Shared OneToSpyOn As Integer
    Public Shared Caller As String
    Public Shared Thingie As PointF

End Class
