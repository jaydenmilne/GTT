﻿Module GameOptions
    Public Buffer As Boolean = True
    Public AntiAlias As Boolean = False
End Module
