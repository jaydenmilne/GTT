﻿<Serializable()>
Public Class AIModule ' no, this isn't actually a module
    ' this was cut to make the deadline... :(

End Class
