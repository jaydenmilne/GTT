﻿<Serializable()>
Public MustInherit Class GeomCreator
    MustOverride Function GetAModel(ByVal Size As SizeF) As DrawModel
End Class
