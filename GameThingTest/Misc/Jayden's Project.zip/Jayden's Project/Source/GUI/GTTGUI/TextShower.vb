﻿Public Class TextShower

    Private Sub TextShower_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = GTTGUI.CodeText
    End Sub
End Class