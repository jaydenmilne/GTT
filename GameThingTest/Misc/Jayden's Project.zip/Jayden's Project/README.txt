Press the about button in game for a more detailed information.

Run GameThingText.exe to play, use WASD to move and "q" to shoot. 
Press "Esc" to go to the pause menu.
Do not modify the source in the "Source.zip" file, you will always have to correct source as long as you have this!

For best results have ratio.ttf, highscore.xml, and entities.bin in GameThingTest.exe's directory.


You should be able to make your own game from this easily.